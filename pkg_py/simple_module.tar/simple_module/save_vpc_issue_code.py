



# import win32gui



def save_vpc_issue_code(issue_code):
    pk_print(f'''issu_code is saved {'%%%FOO%%%' if LTA else ''}''')
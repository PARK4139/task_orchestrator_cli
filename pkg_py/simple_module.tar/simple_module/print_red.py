







def print_red(prompt, flush=True, line_feed_mode=1):
    print_prompt_via_colorama(prompt, ColormaColorMap.RED, flush, line_feed_mode)
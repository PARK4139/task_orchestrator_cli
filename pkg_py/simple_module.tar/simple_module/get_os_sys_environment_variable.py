



# import win32process
# import win32gui
# from project_database.test_project_database import MySqlUtil



def get_os_sys_environment_variable(environment_variable_n: str):
    func_n = inspect.currentframe().f_code.co_name
    return os.environ.get(environment_variable_n)




# import win32gui
# import pywin32
# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely



def pk_assist_to_lock_os_v1():
    from datetime import datetime
    last_cleared_hour = -1  # 아직 클리어된 적 없음을 의미

    while True:
        now = datetime.now()

        # 시간 단위가 바뀌었을 때만 콘솔 클리어
        if now.hour != last_cleared_hour:
            ensure_console_cleared()
            last_cleared_hour = now.hour

        # 잠잘 시간
        if (now.hour == 0 and now.minute >= 12) or (0 < now.hour < 5) or (now.hour == 5 and now.minute <= 30):
            pk_lock_os()

        pk_sleep(milliseconds=10000)
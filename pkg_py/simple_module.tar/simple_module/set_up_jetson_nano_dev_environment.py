



# import pywin32
# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely




def set_up_jetson_nano_dev_environment():
    func_n = inspect.currentframe().f_code.co_name
    # winget # fail # windows 11 부터 시도해보자. 10 지원 끝난듯.
    # winget 윈도우에서 마소 official 패키지 매니저
    # winget --version
    # winget search Google Chrome
    # winget install Google.Chrome --silent
    # winget install Microsoft.VisualStudio --silent

    # choco # fail
    # console_title="choco install"
    # run_powershell_as_admin()
    # write_like_person(string=rf"$host.ui.RawUI.WindowTitle='{console_title}'  ", interval=0.005)
    # press("enter")
    # write_like_person(string=rf"$Host.UI.RawUI.BufferSize=New-Object Management.Automation.Host.Size(1000, 1000) ", interval=0.005)
    # press("enter")
    # write_like_person(string=rf"$Host.UI.RawUI.WindowSize=New-Object Management.Automation.Host.Size(1000, 1000)  ", interval=0.005)
    # press("enter")
    # write_like_person(string=rf" Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol=[System.Net.SecurityProtocolType]::Tls12; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1')) ", interval=0.005)
    # press("enter")
    # choco search usbipd-win
    # choco list #설치된 패키지 확인

    # usbipd
    # chdir(pnx=DOWNLOADS)
    # write_like_person(string=rf"  choco install usbpid-win --silent ", interval=0.005)
    # press("enter")
    # cmd=rf'curl -O "https://github.com/dorssel/usbipd-win/releases/download/v4.3.0/usbipd-win_4.3.0.msi" ' #fail 왜안되나 손으로 클릭하면 되는데
    # cmd=rf'explorer "https://github.com/dorssel/usbipd-win/releases/tag/v4.3.0" '
    # cmd_run(cmd=cmd)
    # pk_sleep(milliseconds=1200)
    # click_text_coordinates_via_easy_ocr(string="usbipd-win_4.3.0.msi")
    # cmd=rf'explorer "{DOWNLOADS}\usbipd-win_4.3.0.msi" '
    # cmd_run(cmd=cmd)
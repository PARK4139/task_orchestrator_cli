





    set_pk_context_state_milliseconds_for_speed_control_forcely



def print_pk_ls_v3(index_map: dict, limit=None):
    #
    pk_print("실행 가능한 pk_ 프로그램 목록:")

    for idx, filepath in index_map.items():

        if limit is not None and idx >= limit:
            pk_print(f"... (이하 {len(index_map) - limit}개 생략됨)")
            break
        pk_print(f"[{idx}] {os.path.basename(filepath)}")




# import win32process
# import win32gui            
# import win32gui
# import pywin32
# import pywin32
# from project_database.test_project_database import MySqlUtil



def is_only_eng_and_no(text):
    pattern = "^[0-9a-zA-Z]+$"
    if re.search(pattern, text):
        return 1
    else:
        return 0
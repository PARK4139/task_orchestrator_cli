





def get_video_filtered_list(d_working, ext_allowed_list, video_ignored_keyword_list):
    # return get_video_filtered_list_v3(d_working, ext_allowed_list, video_ignored_keyword_list)
    return get_video_filtered_list_v4(d_working, ext_allowed_list, video_ignored_keyword_list)
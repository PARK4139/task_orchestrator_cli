





def get_set_from_list(working_list):
    return set(working_list)
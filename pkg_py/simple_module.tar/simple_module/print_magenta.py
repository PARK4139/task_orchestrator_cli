





def print_magenta(prompt, flush=True, line_feed_mode=1):
    print_prompt_via_colorama(prompt, ColormaColorMap.LIGHTMAGENTA_EX, flush, line_feed_mode)
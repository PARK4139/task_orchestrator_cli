



# import win32gui
# import win32gui
# import pywin32
# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely




def move_mouse_rel_x(x_rel: float, y_rel: float):
    func_n = inspect.currentframe().f_code.co_name
    pyautogui.move(x_rel, y_rel)
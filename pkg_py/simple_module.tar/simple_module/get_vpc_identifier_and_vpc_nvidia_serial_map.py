





def get_vpc_identifier_and_vpc_nvidia_serial_map():
    # todo from vpc_db.sqlite
    return {
        'nvidia_serail_example1': 'NO #1 a side',
        'nvidia_serail_example2': 'NO #1 b side',
        'nvidia_serail_example3': 'NX #1 a side',
        'nvidia_serail_example4': 'NX #1 b side',
        'nvidia_serail_example5': 'XC #1',
        'nvidia_serail_example6': 'EVM #1',
    }
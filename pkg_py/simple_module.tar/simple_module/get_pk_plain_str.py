



# import win32gui
# import win32gui
# import pywin32
# import pywin32



def get_pk_plain_str(f_token, f_key):
    config = toml.load(f_token)
    data = config["api"]
    key_byte = get_pk_key_from_f(f=f_key)
    return decrypt_token(data["ciphertext"], data["iv"], key_byte)
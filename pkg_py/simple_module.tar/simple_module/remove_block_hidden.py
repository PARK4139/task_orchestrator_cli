





# import win32gui
# from project_database.test_project_database import MySqlUtil




def remove_block_hidden(driver):
    from selenium.webdriver.common.by import By
    # driver.execute_script("""
    #     const backdrop = document.querySelector('.MuiBackdrop-root');
    #     if (backdrop) {
    #         backdrop.style.display = 'none';
    #     }
    # """)
    try:
        overlay = driver.find_element(By.CSS_SELECTOR, ".MuiModal-root")
        overlay.click()  # 가려진 요소 클릭으로 닫기
        pk_print(working_str="가려진 요소 닫기 성공")
    except Exception as e:
        print(f"가려진 요소 닫기 중 오류 발생: {e}")
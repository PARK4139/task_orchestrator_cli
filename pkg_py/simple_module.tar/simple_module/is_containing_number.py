



# import win32gui
# import win32gui
    set_pk_context_state_milliseconds_for_speed_control_forcely



def is_containing_number(text):
    pattern = "[0-9]"
    if re.search(pattern, text):
        return 1
    else:
        return 0
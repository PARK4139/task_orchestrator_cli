



# import win32gui
# import pywin32
# import pywin32
# from project_database.test_project_database import MySqlUtil




def get_vpc_identifier_matched_from_vpc_db(vpc_nvidia_serial, vpc_side_mode):
    # todo : vpc_db.sqlite or vpc_db.pickle or vpc_db._toml 에서 가져오도록

    f = F_VPC_MAMNAGEMENT_MAP_TOML
    if vpc_identifier:
        return vpc_identifier
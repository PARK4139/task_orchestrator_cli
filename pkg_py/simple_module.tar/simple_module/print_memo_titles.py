



# import win32process
# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely



def print_memo_titles(f):
    # todo
    lines_list = get_line_list_to_include_search_keyword(f=f, search_keywords=["[todo]"])
    lines_list = get_list_removed_element_startswith_str(working_list=lines_list, string="#")
    liens_str = get_str_from_list(working_list=lines_list, item_connector='')

    highlight_config_dict = {
        "bright_red": [
            f'{' %%%FOO%%% ' if LTA else ''}'
        ],
        "white": [
            '[todo]'
        ],
    }
    print_highlighted(txt_whole=liens_str, highlight_config_dict=highlight_config_dict)


def is_number_v2(prompt: str):
    try:
        float(prompt)  # 숫자 형태로 변환을 시도
        return 1
    except ValueError:
        return 0






def get_pk_nick_name_dict():
    return {
        'nick_name': "full_name",
        'vpc': "vision process controller",
    }
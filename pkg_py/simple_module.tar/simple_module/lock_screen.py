



# import win32process
# import win32gui
    set_pk_context_state_milliseconds_for_speed_control_forcely



def lock_screen():
    cmd = "rundll32.exe user32.dll,LockWorkStation"
    if is_os_windows():
        cmd_to_os(cmd=cmd)
    else:
        cmd = get_pnx_wsl_unix_style(pnx=cmd)
        cmd_to_os(cmd=cmd)
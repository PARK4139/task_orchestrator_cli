





# import win32gui
# import pywin32


def run_pk_on_linux(cmd_to_autorun: str,
                    cmd_to_run: str,
                    available_pk_python_program_pnx: str,
                    pk_arg_list: list[str],
                    LTA: bool = False):






def print_parents_process_pid():
    func_n = inspect.currentframe().f_code.co_name
    os.system(rf'powershell (Get-WmiObject Win32_Process -Filter ProcessId=$PID).ParentProcessId')
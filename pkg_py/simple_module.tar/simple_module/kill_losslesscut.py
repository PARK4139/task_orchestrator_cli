








def kill_losslesscut():
    f_losslesscut_exe = get_pnx_windows_style(pnx=F_LOSSLESSCUT_EXE)
    cmd_to_os(cmd='taskkill.exe /im LosslessCut.exe /f')
    pk_print(f"{get_nx(f_losslesscut_exe)} is killed", print_color='green')




def get_p(pnx):
    return rf"{os.path.dirname(pnx)}"




# import pywin32
# import pywin32
# from project_database.test_project_database import MySqlUtil



def run_up_and_down_game():

    func_n = inspect.currentframe().f_code.co_name
    correct_answer: int = random.randint(1, 100)
    left_oportunity: int = 10
    ment = f"<UP AND DOWN GAME>\n\nFIND CORRECT NUMBER"
    pk_speak_v2(working_str=ment, comma_delay=1.0)

    txt_clicked, function, txt_written = should_i_do(
        prompt=ment,
        btn_list=["START", "EXIT"],
        function=None,
        auto_click_negative_btn_after_seconds=30,
        title=f"{func_n}()",
        input_box_mode=False,
    )
    if txt_clicked != "START":
        return

    user_input = None
    is_game_strated = False
    btn_txt_clicked = txt_clicked

    if btn_txt_clicked == "START":
        ment = f"START IS PRESSED, LETS START GAME"
        pk_speak_v2(working_str=ment, comma_delay=0.98, thread_join_mode=True)
        while left_oportunity >= 0:
            if left_oportunity == 0:
                ment = f"LEFT CHANCE IS {left_oportunity} \nTAKE YOUR NEXT CHANCE."
                pk_speak_v2(working_str=ment, comma_delay=0.98)

                txt_clicked, function, txt_written = should_i_do(
                    prompt=ment,
                    btn_list=["EXIT"],
                    function=None,
                    auto_click_negative_btn_after_seconds=None,
                    title=f"{func_n}()",
                    #                    input_box_mode=True,
                )
                if txt_clicked == "EXIT":
                    return

                break
            elif is_game_strated == False or user_input is None:

                ment = f"TYPE NUMBER BETWEEN 1 TO 100"
                if user_input is None:
                    ment = rf"{ment} AGAIN"
                pk_speak_v2(working_str=ment, comma_delay=0.98)
                txt_clicked, function, txt_written = should_i_do(
                    prompt=ment,
                    btn_list=["SUBMIT", "EXIT"],
                    function=None,
                    auto_click_negative_btn_after_seconds=None,
                    title=f"{func_n}()",
                    input_box_mode=True,
                )
                if txt_clicked == "EXIT":
                    return

                user_input = is_user_input_required(txt_written)
                if user_input is not None:
                    left_oportunity = left_oportunity - 1
                is_game_strated = True
            elif user_input == correct_answer:
                ment = f"CONGRATULATIONS\n\nYOUR NUMBER IS {correct_answer}\nTHIS IS ANSWER\n\nSEE YOU AGAIN"
                pk_speak_v2(working_str=ment, comma_delay=0.98)

                txt_clicked, function, txt_written = should_i_do(
                    prompt=ment,
                    btn_list=["SUBMIT", "EXIT"],
                    function=None,
                    auto_click_negative_btn_after_seconds=None,
                    title=f"{func_n}()",
                    input_box_mode=True,
                )
                if txt_clicked == "EXIT":
                    return

            elif correct_answer < user_input:
                ment = f"YOUR NUMBER IS {user_input}\n\nYOU NEED DOWN\n\nYOUR LEFT CHANCE IS {left_oportunity}"
                pk_speak_v2(working_str=ment, comma_delay=0.98)

                txt_clicked, function, txt_written = should_i_do(
                    prompt=ment,
                    btn_list=["SUBMIT", "EXIT"],
                    function=None,
                    auto_click_negative_btn_after_seconds=None,
                    title=f"{func_n}()",
                    input_box_mode=True,
                )
                if txt_clicked == "EXIT":
                    return

                user_input = is_user_input_required(txt_written)
                if user_input is not None:
                    left_oportunity = left_oportunity - 1
            elif correct_answer > user_input:
                ment = f"YOUR NUMBER IS {user_input}\n\nYOU NEED UP\n\nYOUR LEFT CHANCE IS {left_oportunity}"
                pk_speak_v2(working_str=ment, comma_delay=0.98)

                txt_clicked, function, txt_written = should_i_do(
                    prompt=ment,
                    btn_list=["SUBMIT", "EXIT"],
                    function=None,
                    auto_click_negative_btn_after_seconds=None,
                    title=f"{func_n}()",
                    input_box_mode=True,
                )
                if txt_clicked == "EXIT":
                    return

                user_input = is_user_input_required(txt_written)
                if user_input is not None:
                    left_oportunity = left_oportunity - 1
    else:
        return
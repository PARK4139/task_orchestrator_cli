



# import win32gui
# import win32gui
# import pywin32
# import pywin32



def remove_pnx_parmanently(pnx):

    func_n = inspect.currentframe().f_code.co_name
    if platform.system() == 'Windows':
        try:
            if validate_and_return(value=pnx) is not False:
                pk_chdir(os.path.dirname(pnx))
                if os.path.exists(pnx):
                    if is_d(pnx):
                        # shutil.rmtree(pnx_todo)
                        # if is_d(pnx_todo):
                        #     run_via_cmd_exe(rf'echo y | rmdir /s "{pnx_todo}"')
                        move_pnx_to_pk_recycle_bin(pnx)
                    elif is_f(pnx):
                        # os.remove(pnx_todo)
                        # if is_f(pnx_todo):
                        #     run_via_cmd_exe(rf'echo y | del /f "{pnx_todo}"')
                        move_pnx_to_pk_recycle_bin(pnx)

                    # pk_print(f" {'%%%FOO%%%' if LTA else ''} green {texts}" , print_color='blue)
                    # pk_print(f'''{traceback.format_exc()}  {'%%%FOO%%%' if LTA else ''}''', print_color='red')
        except:
            pk_print(f'''{traceback.format_exc()}  {'%%%FOO%%%' if LTA else ''}''', print_color='red')

        finally:
            pk_chdir(D_PROJECT)
    else:
        func_n = inspect.currentframe().f_code.co_name
        try:
            if validate_and_return(value=pnx) is not False:
                pk_chdir(os.path.dirname(pnx))
                if os.path.exists(pnx):
                    if is_d(pnx):
                        shutil.rmtree(pnx)
                    elif is_f(pnx):
                        os.remove(pnx)
        except:
            pk_print(f'''{traceback.format_exc()}  {'%%%FOO%%%' if LTA else ''}''', print_color='red')

        finally:
            pk_chdir(D_PROJECT)
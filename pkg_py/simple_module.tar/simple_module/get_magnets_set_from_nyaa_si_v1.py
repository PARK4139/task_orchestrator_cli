



# import win32process
# import pywin32



def get_magnets_set_from_nyaa_si_v1(nyaa_si_supplier, search_keyword, driver):  # v1 : txt 파일에 데이터를 수집하는 방식

    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from bs4 import BeautifulSoup
    func_n = inspect.currentframe().f_code.co_name

    if driver is None:
        driver = get_driver_selenium(browser_debug_mode=False)

    url = f'https://nyaa.si/user/{nyaa_si_supplier}?f=0&c=0_0&q={get_str_encoded_url(search_keyword)}'
    pk_print(f'''url={url}  {'%%%FOO%%%' if LTA else ''}''')

    driver.get(url)
    page_src = driver.page_source
    soup = BeautifulSoup(page_src, "html.parser")

    page_number_last = None
    files_per_page = 75
    total_cnt_of_f_torrent_list = get_total_cnt_of_f_torrent_list(h3_text=soup.find("h3").text.strip())
    if total_cnt_of_f_torrent_list:
        page_number_last = math.ceil(total_cnt_of_f_torrent_list / files_per_page)
        pk_print(f'''files_per_page={files_per_page}  {'%%%FOO%%%' if LTA else ''}''')
        pk_print(f'''displayable_magnets_cnt_per_page={files_per_page}  {'%%%FOO%%%' if LTA else ''}''')
        pk_print(f'''page_number_last={page_number_last}  {'%%%FOO%%%' if LTA else ''}''')
    else:
        page_number_last = get_page_number_last_of_nyaa_si_page(url=url, driver=driver)

    page_number_str_list = [str(i) for i in get_list_from_int_a_to_int_b(int_a=1, int_b=page_number_last)]
    page_number_start_to_download = int(
        get_value_completed(key_hint='page_number_start_to_download=', values=page_number_str_list))
    page_number_end_to_download = int(
        get_value_completed(key_hint='page_number_end_to_download=', values=page_number_str_list))

    magnets_set = set()
    pk_print(f'''page_number_end_to_download={page_number_end_to_download}  {'%%%FOO%%%' if LTA else ''}''',
             print_color="blue")
    for page_number in range(page_number_start_to_download, page_number_end_to_download + 1):
        url_page = f'{url}&p={page_number}'
        url_decoded = get_str_url_decoded(str_working=url_page)
        pk_print(working_str=rf'''url_page={url_page:60s}  url_decoded={url_decoded}  {'%%%FOO%%%' if LTA else ''}''')
        driver.get(url_page)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
        pk_sleep(milliseconds=random.randint(200, 333))
        page_src = driver.page_source
        soup = BeautifulSoup(page_src, "html.parser")
        # pk_print(f'''soup={soup}  {'%%%FOO%%%' if LTA else ''}''')
        magnet_links = {a["href"] for a in soup.find_all("a", href=True) if a["href"].startswith("magnet:")}
        pk_print(f'''Found {len(magnet_links)} magnet links on page {page_number}''')
        magnets_set |= magnet_links
    pk_print(f'''len(magnets_set)={len(magnets_set)}  {'%%%FOO%%%' if LTA else ''}''')
    return magnets_set




# import win32gui
# import win32gui
# import pywin32
# import pywin32
# from project_database.test_project_database import MySqlUtil



def print_function_info(thing_curious):

    func_n = inspect.currentframe().f_code.co_name
    pk_print(f"{inspect.currentframe().f_code.co_name} {str(thing_curious.__code__.co_varnames)}")
    print(help(thing_curious))
    pk_print(f'# of the Arguments : {thing_curious.__code__.co_argcount}')
    # pk_print(f'Name of the Arguments : {thing_curious.__code__.co_varnames}')
    pk_print(working_str="┌>print via getsource s")
    print(inspect.getsource(thing_curious))
    pk_print(working_str="└>print via getsource e")
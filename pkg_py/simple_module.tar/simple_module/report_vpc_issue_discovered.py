






def report_vpc_issue_discovered():
    pk_print(f'''vpc issue is discovered {'%%%FOO%%%' if LTA else ''}''', print_color='red')
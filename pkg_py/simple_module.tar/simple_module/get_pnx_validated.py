



# import pywin32




def get_pnx_validated(pnx):
    pnx = pnx.strip()
    pnx = get_pnx_os_style(pnx)
    if not os.path.exists(pnx):
        pk_print(f"❌ 경로가 존재하지 않습니다: {pnx}", print_color='red')
        raise
    return pnx






def print_os_sys_environment_variables():
    print_iterable_as_vertical(item_iterable=os.environ, item_iterable_n='모든 시스템 환경변수 출력')

    ipdb.set_trace()
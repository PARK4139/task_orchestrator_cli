



# import win32process
# from project_database.test_project_database import MySqlUtil



def is_current_hostname(hostname):
    current_hostname = get_hostname()
    pk_print(working_str=rf'''hostname="{hostname}"  {'%%%FOO%%%' if LTA else ''}''')
    pk_print(working_str=rf'''current_hostname="{current_hostname}"  {'%%%FOO%%%' if LTA else ''}''')
    if current_hostname == hostname:
        return 1
    else:
        return 0




# import win32gui
# import pywin32



def run_wsl(remote_os_distro_n, wsl_window_title_seg):
    # install wsl
    # install_wsl(remote_os_distro_n)

    if not is_window_opened(window_title_seg=wsl_window_title_seg):
        open_and_move_wsl_console_to_front(remote_os_distro_n=remote_os_distro_n, window_title_seg=wsl_window_title_seg)
    while 1:
        if is_front_window_title(window_title_seg=wsl_window_title_seg):
            break
        ensure_window_to_front(window_title_seg=wsl_window_title_seg)
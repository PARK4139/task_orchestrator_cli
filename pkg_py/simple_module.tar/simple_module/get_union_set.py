



# import win32process



def get_union_set(set_a, set_b):
    """합집합 A ∪ B"""
    return set(set_a) | set(set_b)
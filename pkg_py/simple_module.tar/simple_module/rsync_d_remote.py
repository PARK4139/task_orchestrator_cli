





def rsync_d_remote(d_pnx):
    """이게 뭐냐면 외부망에 있는 d를 동기화. 리눅스 rsync 에 의존하는 기술"""

    # todo : chore :

    if not is_internet_connected():
        raise
    pk_speak(PkMents2025Korean.NOT_PREPARED_YET)
    pass
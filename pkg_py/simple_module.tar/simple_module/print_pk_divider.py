





# import win32process
# import win32gui
# import win32gui
# import pywin32


def print_pk_divider(working_str=''):
    print_magenta(f"{PK_UNDERLINE}{working_str}")
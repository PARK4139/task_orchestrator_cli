



# from project_database.test_project_database import MySqlUtil



def run_powershell_exe_as_admin():
    func_n = inspect.currentframe().f_code.co_name
    # cmd_to_os('PowerShell -cmd "Start-Process powershell"')
    cmd_to_os('powershell -cmd "Start-Process powershell -Verb RunAs"')
    window_title_seg = "관리자: Windows PowerShell"
    while 1:
        if not is_front_window_title(window_title_seg=window_title_seg):
            ensure_window_to_front(window_title_seg=window_title_seg)
        if is_front_window_title(window_title_seg=window_title_seg):
            break
    # window_move_to_front_via_win32gui(window_title_seg=window_title_seg)
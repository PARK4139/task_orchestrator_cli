







def run_losslesscut():
    f_losslesscut_exe = get_pnx_windows_style(pnx=F_LOSSLESSCUT_EXE)
    if not os.path.exists(f_losslesscut_exe):
        if LTA:
            pk_print(f"{get_nx(f_losslesscut_exe)} is not installed", print_color='red')
    else:
        if LTA:
            pk_print(f"{get_nx(f_losslesscut_exe)} is installed", print_color='green')
    cmd_to_os(cmd=rf'''start "" /MAX "{f_losslesscut_exe}"''', mode='a')
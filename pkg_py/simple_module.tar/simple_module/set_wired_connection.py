






def set_wired_connection(vpc_wired_connection, **config_remote_os):
    cmd_list = []
    if vpc_wired_connection["address"] == "":
        cmd_list.append(
            f'sudo nmcli connection modify "Wired connection {vpc_wired_connection['wired_connection_no']}" ipv4.method "{vpc_wired_connection["method"]}"')
        cmd_list.append(
            f'sudo nmcli connection modify "Wired connection {vpc_wired_connection['wired_connection_no']}" ipv4.address "{vpc_wired_connection["address"]}"')
    else:
        cmd_list.append(
            f'sudo nmcli connection modify "Wired connection {vpc_wired_connection["wired_connection_no"]}" ipv4.address "{vpc_wired_connection["address"]}"')
        cmd_list.append(
            f'sudo nmcli connection modify "Wired connection {vpc_wired_connection["wired_connection_no"]}" ipv4.method "{vpc_wired_connection["method"]}"')
    cmd_list.append(
        f'sudo nmcli connection modify "Wired connection {vpc_wired_connection['wired_connection_no']}" ipv4.gateway "{vpc_wired_connection["gateway"]}"')
    cmd_list.append(
        f'sudo nmcli connection modify "Wired connection {vpc_wired_connection['wired_connection_no']}" ipv4.dns "{vpc_wired_connection["dns"]}"')
    for cmd in cmd_list:
        std_out_list, std_err_list = cmd_to_remote_os(cmd=cmd, **config_remote_os)
        std_err = get_str_from_list(working_list=std_err_list)
        if std_err:
            if "\n" in std_err:
                error_list = std_err.split("\n")
                for error_str in error_list:
                    pk_print(f"{STAMP_ERROR}{error_str}", print_color='red')
            else:
                pk_print(f"{STAMP_ERROR}{std_err}", print_color='red')
    cmd_to_remote_os(cmd="sudo systemctl restart NetworkManager", **config_remote_os)
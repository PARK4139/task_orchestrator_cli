



# import win32gui




def print_system_environment_variables():
    """print 시스템 환경변수 path"""
    from os.path import dirname
    sys.path.insert(0, dirname)
    sys.path.append(r'C:\Python312\Lib\site-packages')
    for i in sys.path:
        print(i)




# import win32process
# import win32gui
# import pywin32



def shoot_custom_screenshot():
    asyncio.run(shoot_custom_screenshot_via_asyncio())
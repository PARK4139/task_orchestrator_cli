





def is_day(dd):
    from datetime import datetime
    return datetime.today().day == int(dd)




# import win32process



def send_d_to_remote_os(d_local_src, d_remote_dst, **config_remote_os):


    ip = config_remote_os['ip']
    pw = config_remote_os['pw']
    port = config_remote_os['port']
    user_n = config_remote_os['user_n']
    local_ssh_public_key = config_remote_os['local_ssh_public_key']

    ssh = None
    sftp = None
    f_zip_local = None
    try:
        # compress from d_local to f_zip_local
        f_zip_nx = os.path.basename(d_local_src) + ".zip"
        f_zip_local = os.path.join(os.path.dirname(d_local_src), f_zip_nx)
        f_zip_local = get_pnx_os_style(pnx=f_zip_local)
        shutil.make_archive(base_name=f_zip_local.replace(".zip", ""), format="zip", root_dir=d_local_src)
        if does_pnx_exist(f_zip_local):
            pk_print(f"compress d from d_local to f_zip_local({f_zip_local})")

        f_zip_remote = os.path.join(d_remote_dst, f_zip_nx).replace("\\", "/")

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname=ip, port=port, username=user_n, password=pw)
        sftp = ssh.open_sftp()

        # send d as f_zip
        pk_print(f"start to send d as f_zip from {f_zip_local} to {f_zip_remote}")
        sftp.put(f_zip_local, f_zip_remote)
        pk_print(f"send d as f_zip from {f_zip_local} to {f_zip_remote}", print_color="green")

        # decompress in remote
        cmd = f"unzip -o {f_zip_remote} -d {d_remote_dst}"
        stdin, stdout, stderr = ssh.exec_command(cmd)  # 이 방식.

        # ensure d existance
        # todo

    except Exception as e:
        print(f"Error during directory transfer: {e}")
        raise
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()
        # 잔여 pnx 삭제
        if os.path.exists(f_zip_local):
            os.remove(f_zip_local)
        if LTA:
            pk_print("SSH connection closed.")
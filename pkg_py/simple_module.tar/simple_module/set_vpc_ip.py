



# import win32gui




def set_vpc_ip(vpc_data, **config_remote_os):
    set_wired_connection(vpc_data.vpc_wired_connection_1_new, **config_remote_os)
    set_wired_connection(vpc_data.vpc_wired_connection_3_new, **config_remote_os)




# import win32process


def get_windows_opened_via_pygetwindow():
    windows = pygetwindow.getAllTitles()
    return windows
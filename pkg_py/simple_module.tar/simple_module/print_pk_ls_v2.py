









def print_pk_ls_v2(index_map: dict):
    #

    pk_print("실행 가능한 pk_ 프로그램 목록:")
    for idx, path in index_map.items():
        nx = os.path.basename(path)
        pk_print(f"[{idx}] {nx}")
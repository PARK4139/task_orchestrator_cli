



# import win32gui
# import pywin32



def get_vpc_identifier_by_input(input_ment, vpc_type):
    # todo 숫자 아니면 continue
    state_nick_name_passed = 0
    while 1:
        vpc_identifier_number = input(input_ment)
        vpc_identifier = f'{vpc_type}_#{vpc_identifier_number}'.lower()
        if 'no_#' or 'nx_#' or 'xc_#' or 'evm_#' in vpc_identifier:
            state_nick_name_passed = 1
        if state_nick_name_passed == 1:
            if LTA:
                pk_print(f'''vpc_identifier={vpc_identifier} {'%%%FOO%%%' if LTA else ''}''')
            return vpc_identifier
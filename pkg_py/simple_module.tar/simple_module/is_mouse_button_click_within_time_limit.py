



# import win32gui
# import win32gui




def is_mouse_button_click_within_time_limit(key="left", time_limit=10):
    from pynput import mouse
    if key == "left":
        listener = mouse.Listener(on_click=on_left_click)
    elif key == "right":
        listener = mouse.Listener(on_click=on_right_click)
        # listener=mouse.Listener(on_click=on_right_click())
    listener.start()  # Listener 시작
    listener.join(time_limit)  # 주어진 시간 동안 대기
    listener.stop()  # Listener 종료

    return click_detected  # 클릭 감지 여부 반환




# import win32gui
# import pywin32
# import pywin32


def is_valid_ngram(k: str) -> bool:
    if len(k.split()) < 2:
        return False

    # 숫자 단독, (1080p), 등 무의미한 값 제외
    if re.fullmatch(r"\d+|\d{3,4}p|\(\d{3,4}p\)", k.strip()):
        return False

    # "- 12" 같은 기호+숫자 조합 제거
    if re.fullmatch(r"[-~–—]\s*\d+", k.strip()):
        return False

    # "12 (1080p)" 같은 회차 + 화질 제거
    if re.search(r"\b\d{1,2} ?\(\d{3,4}p\)", k):
        return False

    return True
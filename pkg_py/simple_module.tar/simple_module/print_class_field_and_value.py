



# import win32process
# import win32gui
# import pywin32
# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely




def print_class_field_and_value(class_n):  # print 보다는 get 으로 바꾸는게 좋겠다.

    cmd_usage_explanations = []
    cmd_usage_explanations.append(title)
    cmd_usage_explanations.append('\n')
    cmd_usage_explanations.append('<예시> : python console_blurred.py <mode_option>')
    cmd_usage_explanations.append('\n')
    longest_field = max(vars(class_n), key=len)  # mkr_get_longest_field_name
    longest_value = vars(class_n)[longest_field]  # mkr_get_longest_field_value
    for key, value in class_n.__dict__.items():  # mkr_get_field_name_and_field_value
        if not key.startswith('__'):  # 내장 속성 제외
            cmd_usage_explanations.append(f"{key}{" " * (len(longest_field) - len(key))}: {value}")
    cmd_usage_explanations.append('\n')
    for cmd_usage_explanation in cmd_usage_explanations:
        pk_print(working_str=cmd_usage_explanation)
    cmd_usage_explanations.append('\n')
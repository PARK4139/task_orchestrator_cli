





def get_list_reversed(working_list):
    working_list.reverse()
    return working_list
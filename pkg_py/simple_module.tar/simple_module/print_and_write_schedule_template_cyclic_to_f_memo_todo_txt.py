



# import pywin32


def print_and_write_schedule_template_cyclic_to_f_memo_todo_txt(
        stamp_custom, todo_task_name_str, start_date, end_date, f_txt,
        period="daily", specific_day=None, specific_weekday=None, specific_week=None, specific_month=None
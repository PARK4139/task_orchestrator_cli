



# import win32process
# import win32gui


def pk_delete_empty_d_list():

    def _delete_tree(root_path: str):
        """
        주어진 디렉토리(root_path)를 후위 순회로 삭제합니다.
        """
        # 먼저 하위 항목들 처리
        for entry in os.scandir(root_path):
            path = entry.path
            if entry.is_dir(follow_symlinks=False):
                # 서브디렉토리 재귀 삭제
                _delete_tree(path)
            else:
                # 파일 삭제
                os.remove(path)
        # 하위 항목까지 다 비워졌으면 자신(빈 디렉토리)도 삭제
        os.rmdir(root_path)

    option_values = [D_WORKING, D_PROJECT, D_DOWNLOADS]
    d_working = get_value_completed(
        key_hint='d_working=',
        values=option_values
    )

    if not os.path.isabs(d_working):
        raise ValueError(f"절대경로를 입력해야 합니다: {d_working!r}")
    if not os.path.isdir(d_working):
        return

    _delete_tree(d_working)
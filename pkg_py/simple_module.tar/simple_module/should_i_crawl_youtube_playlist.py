



# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely




def should_i_crawl_youtube_playlist():
    while 1:
        # 테스트용
        keyword = 'blahblah'
        url = f'https://www.youtube.com/@{keyword}/playlists'

        dialog = GuiUtil.CustomQdialog(prompt="해당 페이지의 video title, video url을 크롤링할까요?", btn_list=[YES, NO],
                                       input_box_mode=True, input_box_text_default=url)
        dialog.exec()
        btn_txt_clicked = dialog.btn_txt_clicked

        if btn_txt_clicked == PkMessages2025.YES:
            crawl_youtube_playlist(url=dialog.input_box.text())
            break
        else:
            break
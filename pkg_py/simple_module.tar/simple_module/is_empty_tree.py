



# import win32process
# import win32gui



def is_empty_tree(d):

    pk_print(f"d={d}  {'%%%FOO%%%' if LTA else ''}")

    try:
        with os.scandir(d) as entries:
            for entry in entries:
                if entry.is_file():
                    pk_print(rf"is not empty d {d}")
                    return 0
        pk_print(rf"is not empty d 있습니다.{d}")
        return 1
    except:
        # pk_print(f"{traceback.format_exc()}  {'%%%FOO%%%' if LTA else ''}", print_color='red')
        return 0








def guide_to_manual_remedy(prompt_remedy):
    print(f'\n')
    pk_copy(working_str=prompt_remedy)
    pk_print(f'{PK_UNDERLINE}')
    pk_print(f'{STAMP_TRY_GUIDE} {prompt_remedy}')
    pk_print(f'{PK_UNDERLINE}')
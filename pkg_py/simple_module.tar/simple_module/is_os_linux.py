



# import win32process
# import win32gui
# import pywin32


def is_os_linux():
    #
    # todo 명시적으로 업데이트 필요
    if is_os_wsl_linux():
        return True
    if not is_os_windows():
        return True
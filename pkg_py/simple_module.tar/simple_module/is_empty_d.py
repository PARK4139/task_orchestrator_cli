







def is_empty_d(d_src, debug_mode=True):

    try:
        if len(os.listdir(d_src)) == 0:
            return 1
        else:
            return 0
    except:
        pk_print(f'''{traceback.format_exc()}  {'%%%FOO%%%' if LTA else ''}''', print_color='red')
        return None
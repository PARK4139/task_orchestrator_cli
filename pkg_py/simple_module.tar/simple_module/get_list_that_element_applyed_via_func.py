






def get_list_that_element_applyed_via_func(func, working_list):
    return [func(item) for item in working_list]




# import win32process
# import pywin32
# import pywin32
# from project_database.test_project_database import MySqlUtil




def set_state_from_f_pk_config_toml(pk_state_address, pk_state_value):
    pk_toml_address_list = pk_state_address.split('/')
    if LTA:
        pk_print(f'''pk_state_address={pk_state_address} {'%%%FOO%%%' if LTA else ''}''')
        pk_print(f'''pk_state_value={pk_state_value} {'%%%FOO%%%' if LTA else ''}''')
    level_1_dict_n = ""
    level_2_dict_n = ""
    level_3_dict_n = ""
    try:
        level_1_dict_n = pk_toml_address_list[0]
        level_2_dict_n = pk_toml_address_list[1]
        level_3_dict_n = pk_toml_address_list[2]
    except:
        if LTA:
            pk_print(f'''{len(pk_toml_address_list)} is idx limit. in setter {'%%%FOO%%%' if LTA else ''}''')

    level_1_dict = {}
    level_2_dict = {}
    level_3_dict = {}
    try:
        level_1_dict = toml.load(F_PK_CONFIG_TOML)[level_1_dict_n]
    except KeyError:
        pk_print(f'''level_1_dict={level_1_dict}에 해당하는 key 가 없어 생성합니다. {'%%%FOO%%%' if LTA else ''}''')
        level_1_dict = toml.load(F_PK_CONFIG_TOML)[level_1_dict]
        with open(F_PK_CONFIG_TOML, "w") as f:
            toml.dump(level_1_dict, f)
    try:
        level_2_dict = level_1_dict[level_2_dict_n]
    except KeyError:
        pk_print(f'''level_2_dict_n={level_2_dict_n}에 해당하는 key 가 없어 생성합니다. {'%%%FOO%%%' if LTA else ''}''')
        level_1_dict[level_2_dict_n] = pk_state_value
        with open(F_PK_CONFIG_TOML, "w") as f:
            toml.dump(level_1_dict, f)
    if len(pk_toml_address_list) == 2:
        level_1_dict[level_2_dict_n] = pk_state_value
        with open(F_PK_CONFIG_TOML, "w") as f:
            toml.dump(level_1_dict, f)
    try:
        level_3_dict = level_2_dict[level_3_dict_n]
    except KeyError:
        pk_print(f'''level_3_dict_n={level_3_dict_n}에 해당하는 key 가 없어 생성합니다. {'%%%FOO%%%' if LTA else ''}''')
        level_2_dict[level_3_dict_n] = pk_state_value
        with open(F_PK_CONFIG_TOML, "w") as f:
            toml.dump(level_2_dict, f)
    if len(pk_toml_address_list) == 3:
        level_2_dict[level_3_dict_n] = pk_state_value
        with open(F_PK_CONFIG_TOML, "w") as f:
            toml.dump(level_2_dict, f)




# import pywin32



def kill_os():

    pk_print(f"{inspect.currentframe().f_code.co_name}()")
    shutdown_this_computer()




def keyUp(key: str):
    func_n = inspect.currentframe().f_code.co_name
    pyautogui.keyUp(key)




# import pywin32




def rerun_pnx(my_name):  # 종료용이름 시작용이름 이 다름 따로 수집해서 코딩 필요

    func_n = inspect.currentframe().f_code.co_name
    kill_process_via_taskkill(process_name=my_name)
    pk_sleep(milliseconds=200)  # 최적화 테스트 필요
    cmd = rf'start "{my_name}"'
    cmd_to_os(cmd=cmd, mode="a")
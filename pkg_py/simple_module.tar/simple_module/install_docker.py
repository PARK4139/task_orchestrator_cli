



# import win32gui
# import pywin32
# import pywin32
# from project_database.test_project_database import MySqlUtil



def install_docker(**config_remote_os):
    std_out_list, std_err_list = cmd_to_remote_os_with_pubkey(cmd='sudo apt update', **config_remote_os)
    std_out_list, std_err_list = cmd_to_remote_os_with_pubkey(
        cmd='curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg',
        **config_remote_os)  # GPG 키 추가
    std_out_list, std_err_list = cmd_to_remote_os_with_pubkey(
        cmd='sudo apt install -y apt-transport-https ca-certificates curl software-properties-common gnupg lsb-release',
        **config_remote_os)  # wsl docker dependency
    std_out_list, std_err_list = cmd_to_remote_os_with_pubkey(
        cmd='echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null',
        **config_remote_os)  # Docker 리포지토리 추가
    std_out_list, std_err_list = cmd_to_remote_os_with_pubkey(cmd='sudo apt update', **config_remote_os)
    std_out_list, std_err_list = cmd_to_remote_os_with_pubkey(
        cmd='sudo apt install -y docker-ce docker-ce-cli containerd.io', **config_remote_os)
    std_out_list, std_err_list = cmd_to_remote_os_with_pubkey(cmd='sudo usermod -aG docker $USER', **config_remote_os)







def pk_log_step(step_label: str):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            pk_print(f"[{step_label}] Starting")
            result = func(*args, **kwargs)
            pk_print(f"[{step_label}] Completed")
            return result

        return wrapper

    return decorator
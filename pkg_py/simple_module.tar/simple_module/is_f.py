





def is_f(pnx):
    if os.path.isfile(pnx):
        return 1
    else:
        return 0






def get_random_hex():

    return secrets.token_hex(16)  # 16바이트의 난수를 16진수 문자열로 생성
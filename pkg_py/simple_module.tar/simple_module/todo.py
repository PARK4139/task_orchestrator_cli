





# import win32gui
# import pywin32
# import pywin32



# , pk_measure_memory
# from pkg_py.pk_system_layer_800_time_and_lanauge_util import pk_sleep

T = TypeVar('T')


def todo(id):
    pk_print(f'''여기 할 차례입니다. at {id}. {'%%%FOO%%%' if LTA else ''}''', print_color="blue")
    raise
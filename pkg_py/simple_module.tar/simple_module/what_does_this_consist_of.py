





def what_does_this_consist_of(text: str):
    result = []
    if is_containing_kor(text=text):
        result.append("kor")
    if is_containing_eng(text=text):
        result.append("eng")
    if is_containing_number(text=text):
        result.append("number")
    if is_containing_special_characters_with_thread(text=text):
        result.append("special_characters")
    if is_containing_jpn(text=text):
        result.append("jpn")
    # print_magenta(rf'text : {text}   result : {result}')
    return result
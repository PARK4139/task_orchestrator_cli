






def run_console_blurred_exe():
    func_n = inspect.currentframe().f_code.co_name
    # console_blurred.exe exec
    cmd_str = rf".\dist\console_blurred\console_blurred.exe"
    cmd_to_os(cmd_str)
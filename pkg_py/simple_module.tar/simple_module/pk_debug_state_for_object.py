



def pk_debug_state_for_object(stamp, **kwargs):
    # todo
    pass
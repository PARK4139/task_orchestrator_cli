



# import win32process
# import win32gui
# import pywin32
# from project_database.test_project_database import MySqlUtil




def xfreerdp(users, ip, remote_os_distro_n, wsl_window_title_seg, pw, exit_mode):
    # todo
    cmd = 'wsl sudo apt update'
    cmd_to_os(cmd=cmd)

    cmd = 'sudo apt install freerdp2-x11'
    cmd_to_os(cmd=cmd)

    #         write_like_person(rf'xfreerdp /v:{ip}:3390 /u:{users} /p:{pw} /sec:nla /clipboard',remote_os_distro_n=remote_os_distro_n, wsl_window_title_seg=wsl_window_title_seg)
    #         write_like_person(rf'xfreerdp /v:{ip}:3390 /u:{users} /p:{pw} /sec:tls /clipboard',remote_os_distro_n=remote_os_distro_n, wsl_window_title_seg=wsl_window_title_seg)
    cmd_to_wsl_os_like_person(cmd=rf'xfreerdp /v:{ip}:3390 /u:{users} /p:{pw} /clipboard',
                              remote_os_distro_n=remote_os_distro_n, wsl_window_title_seg=wsl_window_title_seg)
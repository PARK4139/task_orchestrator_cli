



# import win32process
# import win32gui




def is_eng_or_kor_ja(text: str):
    """
    한글처리 :
        한영숫특 :
        한숫특 :
        한숫
        한특
        숫특
        특
        숫
    영어처리 :
        영숫특
        영특
        영숫
        영
    일어처리 :
    빠진거있나? 일단 여기까지

    문자구성 판별기가 필요하다
        return "eng, kor, jap, special_characters ", ... 이런식 > what_does_this_consist_of() 를 만들었다.
    """
    if is_only_speacial_characters(text=text):
        return "ko"
    elif is_only_no(text=text):
        return "ko"
    elif is_containing_kor(text=text):
        return "ko"
    if is_only_eng_and_no_and_speacial_characters(text=text):
        return "en"
    elif is_only_eng_and_speacial_characters(text=text):
        return "en"
    elif is_only_eng_and_no(text=text):
        return "en"
    elif is_only_eng(text=text):
        return "en"
    else:
        return "ko"
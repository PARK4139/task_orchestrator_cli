





# import pywin32




def get_wsl_ip(wsl_distro_n):
    if is_os_windows():
        std_out_list = cmd_to_os(rf'wsl -d {wsl_distro_n} hostname -I', encoding='utf-8')
    else:
        if is_os_wsl_linux():
            std_out_list = cmd_to_os(rf'hostname -I', encoding='utf-8')
        else:
            pass
    ip_wsl = std_out_list[0].split(" ")[0]
    if ip_wsl:
        if not ping(ip=ip_wsl):
            pk_print(working_str=rf'''ping {ip_wsl}  {'%%%FOO%%%' if LTA else ''}''', print_color='red')
            raise
    return ip_wsl
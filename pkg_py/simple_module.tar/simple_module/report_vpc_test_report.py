



# import win32gui
    set_pk_context_state_milliseconds_for_speed_control_forcely



def report_vpc_test_report(issue_code, solution_code):
    # issue discovered
    pass
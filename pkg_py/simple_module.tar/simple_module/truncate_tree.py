



# import win32gui



def truncate_tree(d_src):
    func_n = inspect.currentframe().f_code.co_name
    if os.path.exists(d_src):
        shutil.rmtree(d_src)
    if not os.path.exists(d_src):
        ensure_pnx_made(d_src, mode="d")






# import win32gui


def get_pnx(pnx):
    return pnx
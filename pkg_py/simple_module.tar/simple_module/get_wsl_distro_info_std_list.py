







def get_wsl_distro_info_std_list() -> list[str]:
    try:
        result = subprocess.run(['wsl', '-l', '-v'], capture_output=True)
        output = result.stdout.decode('utf-16')  # ✅
        std_list = output.splitlines()
        highlight_config_dict = {
            "green": [
                'Running'
            ],
            'red': [
                'Stopped'
            ],
        }
        return std_list
    except Exception as e:
        pk_print(f"Failed to get WSL details: {e}", print_color='red')
        return []
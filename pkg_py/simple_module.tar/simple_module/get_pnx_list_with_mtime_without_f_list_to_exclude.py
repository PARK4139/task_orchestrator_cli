



# import pywin32



def get_pnx_list_with_mtime_without_f_list_to_exclude(d_src):

    f_list_to_exclude = [
        F_DB_YAML,
        F_SUCCESS_LOG,
        F_LOCAL_PKG_CACHE,
    ]
    f_list_of_d = []
    for root, _, f_nx_list in os.walk(d_src):
        for f_nx in f_nx_list:
            if not f_nx.endswith(".mp3"):  # 모든 mp3 f을 배제
                f = os.path.join(root, f_nx)
                if f not in f_list_to_exclude:
                    # files_of_d[rf"{file_path}"]=os.path.getmtime(file_path)
                    f_list_of_d.append([f, os.path.getmtime(f)])
    return f_list_of_d




# import win32gui
# import pywin32
# from project_database.test_project_database import MySqlUtil




def save_screen():
    # cmd_to_os_like_person(cmd=rf'''%systemroot%\system32\scrnsave.scr /s''')# 성공
    cmd = rf'''%systemroot%\system32\scrnsave.scr /s '''  # 성공
    if is_os_windows():
        cmd_to_os(cmd=cmd)
    else:
        cmd = get_pnx_wsl_unix_style(pnx=cmd)
        cmd_to_os(cmd=cmd)
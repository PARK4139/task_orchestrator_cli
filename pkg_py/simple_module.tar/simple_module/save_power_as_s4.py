



# import win32process
# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely




def save_power_as_s4():
    # h3
    # 최대절전모드
    cmd = r'C:\Windows\System32\rundll32.exe powrprof.dll,SetSuspendState hibernate'
    if is_os_windows():
        cmd_to_os(cmd=cmd)
    else:
        cmd = get_pnx_wsl_unix_style(pnx=cmd)
        cmd_to_os(cmd=cmd)
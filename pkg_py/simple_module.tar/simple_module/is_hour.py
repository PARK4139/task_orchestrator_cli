





def is_hour(hh):
    from datetime import datetime
    return datetime.today().hour == int(hh)
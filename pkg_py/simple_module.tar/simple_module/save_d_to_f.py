






def save_d_to_f(d, f):
    with open(f, "w", encoding='utf-8') as f_obj:
        d = get_pnx_os_style(d)
        f_obj.write(d)
        if LTA:
            pk_print(f'''d={d} %%%FOO%%%''')
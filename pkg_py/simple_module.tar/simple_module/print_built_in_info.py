



# import pywin32
# import pywin32



def print_built_in_info(thing_curious):

    func_n = inspect.currentframe().f_code.co_name
    pk_print(f"{inspect.currentframe().f_code.co_name} {str(thing_curious.__code__.co_varnames)}")
    pk_print(working_str="_______________________________________________________________ " + str() + "(" + str(
        thing_curious) + ") s")
    pk_print(working_str="print(inspect.getsource(thing_curious))")
    print(inspect.getsource(thing_curious))
    pk_print(working_str="for i in inspect.getmembers(thing_curious_):")
    for i in inspect.getmembers(thing_curious):
        print(i)
    pk_print(working_str="print(help(thing_curious))")
    print(help(thing_curious))
    pk_print(working_str="[x for x in dir(thing_curious) if '__' not in x]")
    foo = [x for x in dir(thing_curious) if '__' not in x]
    # dir() 함수는 값 없이 지정된 객체의 모든 속성과 메서드를 반환합니다 .
    # 이 함수는 모든 속성과 메서드를 반환하며, 모든 개체에 대한 기본값인 내장 속성도 반환합니다.
    pk_print(working_str="[x for x in dir(thing_curious) if '__' not in x]")
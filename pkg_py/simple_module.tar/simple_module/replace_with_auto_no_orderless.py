



# import win32gui
# import pywin32
# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely



def replace_with_auto_no_orderless(contents: str, unique_word: str, auto_cnt_starting_no=0):
    func_n = inspect.currentframe().f_code.co_name
    # pk_print(str_working="항상 필요했던 부분인데 만들었다. 편하게 개발하자. //웹 서비스 형태로 아무때서나 접근이되면 더 좋을 것 같다.  웹 개발툴 을 만들어 보자")
    before = unique_word
    after = 0 + auto_cnt_starting_no
    contents_new = []
    # lines=contents.split("\n")
    lines = contents.strip().split("\n")  # 문제 없긴 했는데,  어떻게 되나 실험해보자 안되면 위의 코드로 주석 스와핑할것.
    for line in lines:
        # pk_print(line)
        # pk_print(before)
        # pk_print(str(after))
        after = after + 1

        line_new = re.sub(str(before), str(after), str(line))
        # pk_print(line_new)
        contents_new.append(line_new)

    # pk_print(str_working="str list to str")
    delimiter = "\n"
    contents_new_as_str = delimiter.join(contents_new)
    return contents_new_as_str
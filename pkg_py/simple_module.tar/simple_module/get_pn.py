





def get_pn(pnx):
    return rf"{os.path.dirname(pnx)}\{os.path.splitext(os.path.basename(pnx))[0]}"
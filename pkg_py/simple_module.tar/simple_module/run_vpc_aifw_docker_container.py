



# import pywin32
# from project_database.test_project_database import MySqlUtil



def run_vpc_aifw_docker_container(vpc_data, config_remote_os):
    if vpc_data.vpc_type == 'no':
        config_remote_os(cmd='sudo run_container -b', **config_remote_os)
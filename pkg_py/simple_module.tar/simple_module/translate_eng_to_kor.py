



# import win32process




def translate_eng_to_kor(question: str):

    if not is_internet_connected():
        raise
    try:
        while 1:
            try:
                question = question.strip('""')
            except AttributeError:
                break
            pk_press("win", "m")

            # 구글 번역 페이지로 이동
            url = "https://www.google.com/search?q=eng+to+kor"
            cmd = f'explorer "{url}" >nul'
            cmd_to_os_like_person_as_admin(cmd)

            # 크롬 창 활성화
            target_pid: int = get_pids(process_img_n="chrome.exe")  # chrome.exe pid 가져오기
            ensure_window_to_front(pid=target_pid)

            # 텍스트를 입력하세 클릭
            f_png = rf"{D_PROJECT}\pkg_png\eng to kor.png"
            click_center_of_img_recognized_by_mouse_left(img_pnx=f_png, is_zoom_toogle_mode=True, loop_limit_cnt=100)

            # 번역할 내용 작성
            write_fast(question)

            # 글자수가 많으면 text to voice icon 이 잘려서 보이지 않음. 이는 이미지의 객체 인식이 불가능해지는데
            # 스크롤를 내려서 이미지 인식을 가능토록
            if len(question) > 45:
                pyautogui.vscroll(-15)
            pk_sleep(30)

            # text to voice icon
            f_png = rf"{D_PROJECT}\pkg_png\text to voice icon.png"
            click_center_of_img_recognized_by_mouse_left(img_pnx=f_png, is_zoom_toogle_mode=True, loop_limit_cnt=100)

            # 종료
            break
    except:
        traceback.print_exc(file=sys.stdout)
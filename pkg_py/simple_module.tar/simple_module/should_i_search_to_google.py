



# import win32gui




def should_i_search_to_google():
    # todo : ref : as gui : demerit : slow
    # import pk_system_layer_static_logic
    # txt_clicked, function, txt_written = should_i_do(
    #     string=rf"can i search contents dragged to google?",
    #     btns=[pk_system_layer_static_logic.POSITIVE, pk_system_layer_static_logic.NEGATIVE],
    #     function=partial(ask_to_google, question=question),
    #     auto_click_negative_btn_after_seconds=30,
    #     title=f" {'%%%FOO%%%' if LTA else ''}",
    #     input_box_mode=True,
    #     input_box_text_default=question,
    # )
    # if txt_clicked == pk_system_layer_static_logic.NEGATIVE:
    #     pk_print(f'''{pk_system_layer_static_logic.NEGATIVE} pressed  {'%%%FOO%%%' if LTA else ''}''', print_color='red')
    #     return
    # if txt_clicked == pk_system_layer_static_logic.POSITIVE:
    #     pk_print(f'''txt_clicked={txt_clicked}  {'%%%FOO%%%' if LTA else ''}''', print_color="blue")
    #     pk_print(f'''txt_written={txt_written}  {'%%%FOO%%%' if LTA else ''}''', print_color="blue")
    #     function()

    # todo : ref : as cli
    txt_written = should_i_do_cli(
        title=rf"can i search contents dragged to google?",
        search_keyword_default="",
    )
    txt_written = txt_written.strip()
    if txt_written != "":
        ask_to_google(txt_written)






def get_str_from_f(f):

    func_n = inspect.currentframe().f_code.co_name

    pk_print(f'''f={f}''')

    if f is None:
        return ""

    try:
        if os.path.exists(f):
            # f 읽기
            with open(file=f, mode='r', encoding=Encoding.UTF8.value, errors='ignore') as f:
                content = f.read()  # f 내용을 문자열로 읽기
                if content is None:
                    return ""
                return content
    except:
        pk_print(f'''{traceback.format_exc()}  {'%%%FOO%%%' if LTA else ''}" ''', print_color='red')
        return ""







def pk_input(working_str, limit_seconds, return_default, get_input_validated=None):
    return pk_input_v44_uv_theme(working_str, limit_seconds, return_default, get_input_validated)
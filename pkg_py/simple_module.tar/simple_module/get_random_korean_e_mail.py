





def get_random_korean_e_mail():
    return secrets.choice([
        'john.doe@gmail.com', 'jane.smith@yahoo.com', 'david.wilson@hotmail.com', 'emily.johnson@outlook.com',
        'michael.brown@aol.com', 'sarah.jones@icloud.com', 'robert.davis@protonmail.com', 'lisa.thomas@zoho.com',
        'william.martin@yandex.com', 'jessica.anderson@mail.com',
        'matthew.harris@live.com', 'laura.miller@gmx.com', 'james.jackson@fastmail.com', 'olivia.rodriguez@inbox.com',
        'benjamin.carter@ymail.com', 'mia.walker@rocketmail.com', 'ethan.white@tutanota.com', 'ava.hall@rediffmail.com',
        'alexander.lee@mailinator.com', 'sophia.green@protonmail.ch', 'jacob.adams@yandex.ru', 'emma.baker@outlook.com',
        'daniel.cook@zoho.eu', 'madison.lopez@google.com',
        'logan.morgan@yahoo.co.uk', 'chloe.roberts@icloud.com', 'jayden.kelly@mail.com', 'grace.bennett@fastmail.fm',
        'samuel.rogers@protonmail.com', 'harper.edwards@outlook.com'
    ])
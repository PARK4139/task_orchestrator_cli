





def get_random_korean_name():
    return secrets.choice([
        "김민지", "이준호", "박지영", "정성민", "홍길동", "김지현", "박민수", "이서연", "정현우", "한지원", "박정훈"
    ])
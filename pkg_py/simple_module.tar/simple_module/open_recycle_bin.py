






def open_recycle_bin():
    cmd_to_os(cmd='explorer.exe shell:RecycleBinFolder')
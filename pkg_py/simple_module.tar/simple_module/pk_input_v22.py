



# import win32process



def pk_input_v22(
        working_str: str,
        limit_seconds: int = 30,
        return_default: str | None = None,
        *,
        get_input_validated=None,  # bool 반환 함수
        verbose_log: bool = True,
        masked: bool = False,
        auto_repeat: bool = False,
        fuzzy_accept: list[tuple[str, ...]] | None = None,
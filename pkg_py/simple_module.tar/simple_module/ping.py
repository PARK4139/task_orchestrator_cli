



# import pywin32



def ping(ip):
    return ping_v3(ip)
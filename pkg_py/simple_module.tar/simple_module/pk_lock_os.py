



# import pywin32
# from project_database.test_project_database import MySqlUtil



def pk_lock_os():
    if is_os_windows():
        save_power_as_s3()
    elif is_os_wsl_linux():
        save_power_as_s3()
    else:
        cmd_to_os('echo TBD')






# from project_database.test_project_database import MySqlUtil




def quit_autoa2z_drive():

    window_title_seg = "AutoA2Z Drive"
    timeout = 5
    start_time = time.time()
    while 1:
        if time.time() - start_time > timeout:
            break
        if is_window_opened(window_title_seg=window_title_seg):
            window_title_seg = "AutoA2ZDrive_Release.exe"
            while 1:
                pid = get_pid_by_window_title_via_tasklist(window_title_seg=window_title_seg)
                if is_number_v2(prompt=pid):
                    # cmd = rf' taskkill /f /pid {pid} '
                    # cmd_to_os_like_person(cmd=cmd, admin_mode=True) # fail
                    # cmd_to_os_like_person_as_admin(cmd=cmd)

                    cmd = rf' Stop-Process -Id {pid} -Force'
                    cmd_to_os_via_powershell_exe(cmd=cmd)
                    write_like_person(str_working='exit')
                    pk_press("enter")
                else:
                    break

            break
        else:
            break




# import win32gui



def keyDown(key: str):
    func_n = inspect.currentframe().f_code.co_name
    pyautogui.keyDown(key)
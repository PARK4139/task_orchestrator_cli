





def print_light_yellow(prompt, flush=True, line_feed_mode=1):
    print_prompt_via_colorama(prompt, ColormaColorMap.LIGHTYELLOW_EX, flush, line_feed_mode)




# import win32process
# import pywin32




def print_event_info_(event, thing_curious):
    """
        jhp_debugger.print_event_info_(event)
        # └>call sample
    """
    func_n = inspect.currentframe().f_code.co_name
    print(str(event))
    # print(event.type())
    # if type(thing_curious)==str:
    #     print('{{mkr}}')
    # if type(thing_curious)==list:
    #     print(thing_curious[str(event.type())])
    # if type(thing_curious) == tuple:
    #     print('{{mkr}}')




# import win32process



def get_str_replaced_from_str_to_str_new(item_str, from_str, to_str):
    pk_print(f'''item_str="{item_str}"''')
    pk_print(f'''from_str="{from_str}"''')
    pk_print(f'''to_str="{to_str}"''')
    if not isinstance(item_str, str):
        raise TypeError("item_str must be a string.")
    if not isinstance(from_str, str):
        raise TypeError("from_str must be a string.")
    if not isinstance(to_str, str):
        raise TypeError("to_str must be a string.")
    item_str = item_str.replace(from_str, to_str)
    pk_print(f'''item_str="{item_str}"''')
    return item_str
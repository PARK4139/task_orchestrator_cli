



# import win32process
# import win32gui



def rename_pnx_list_at_d(d_working, mode, with_walking, debug_mode=False):
    pk_print(working_str=rf'''d="{d_working}" mode="{mode}"  {'%%%FOO%%%' if LTA else ''}''')

    rename_pnxs_from_keywords_to_keyword_new_at_d(d=d_working, mode=mode, with_walking=with_walking)
    rename_pnxs_from_pattern_to_pattern_new_via_routines_at_d(d=d_working, mode=mode, with_walking=with_walking)
    rename_pnxs_from_keywords_to_keyword_new_at_d(d=d_working, mode=mode, with_walking=with_walking)
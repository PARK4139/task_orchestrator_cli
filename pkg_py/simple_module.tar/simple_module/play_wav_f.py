





def play_wav_f(f):
    f = pk_system_layer_static_logic.F_POP_SOUND_POP_SOUND_WAV
    if os.path.exists(f):
        source = pyglet.media.load(f)
        source.play()
    pass
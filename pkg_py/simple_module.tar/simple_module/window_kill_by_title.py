



def window_kill_by_title(window_title):
    kill_window_by_title_via_wind32con(window_title)
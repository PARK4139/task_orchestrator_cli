





def get_set_unioned(set_a, set_b):
    return get_union_set(set_a, set_b)
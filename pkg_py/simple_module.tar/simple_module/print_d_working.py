





def print_d_working():
    pk_print(get_d_working())
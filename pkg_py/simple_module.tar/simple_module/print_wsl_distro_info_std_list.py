



# import pywin32
# import pywin32




def print_wsl_distro_info_std_list() -> list[str]:
    try:
        pk_print("======== wsl -l -v ========")
        std_list = get_wsl_distro_info_std_list()
        highlight_config_dict = {
            "green": [
                'Running'
            ],
            'red': [
                'Stopped'
            ],
        }
        pk_debug_state_for_py_data_type(pk_stamp='%%%FOO%%%-1', data_working=std_list,
                                        highlight_config_dict=highlight_config_dict, with_LTA=0)
        return std_list
    except Exception as e:
        pk_print(f"Failed to get WSL details: {e}", print_color='red')
        return []








def pk_here(item_str=None):

    func_n = inspect.currentframe().f_code.co_name
    if item_str is None:
        item_str = ''
    pk_print(rf"{str(str(item_str) + ' ') * 242:.100} here!")
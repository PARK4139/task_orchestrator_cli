



def get_os_n():
    if platform.system() == 'Windows':
        return 'Windows'.lower()
    elif platform.system() == 'Linux':
        return 'Linux'.lower()
    else:
        return 'Unknown'.lower()
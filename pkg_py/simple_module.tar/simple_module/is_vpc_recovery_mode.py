





def is_vpc_recovery_mode(vpc_data):
    # todo :
    pass
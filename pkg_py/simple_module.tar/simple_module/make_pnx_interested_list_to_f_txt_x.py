



# import win32process
    set_pk_context_state_milliseconds_for_speed_control_forcely



def make_pnx_interested_list_to_f_txt_x(d_working_list, exclusion_list):

    # todo : chore : f 내용 초기화
    func_n = inspect.currentframe().f_code.co_name
    pnx_processed_list = []
    file_cnt = 0
    write_cnt = 0
    write_cnt_limit = 1000000
    for pnx_interested in d_working_list:
        pnxs_with_walking = get_pnx_list(d_working=pnx_interested, mode="f", with_walking=1)

        # 'pnxs_exclude'를 set으로 변경하여 'in' 연산을 최적화
        func_n_file_cnt_txt = None
        for pnx_with_walking in pnxs_with_walking:
            # 빠른 'in' 연산을 위해 set으로 변환된 pnxs_exclude 활용
            if any(pnx_exclude in pnx_with_walking for pnx_exclude in exclusion_list):
                continue  # 'pnx_exclude'에 포함되면 건너뛰기
            # 'exclude' 목록에 포함되지 않으면 'pnx_processed_list'에 추가
            pnx_processed_list.append(pnx_with_walking)
            # pk_print(str_working=rf'''len(pnx_processed_list)="{len(pnx_processed_list)}"  {'%%%FOO%%%' if LTA else ''}''')
            if write_cnt == write_cnt_limit % 2 == 0:
                file_cnt = file_cnt + 1
                # print_iterable_as_vertical(item_iterable=pnx_processed_list, item_iterable_n="pnx_processed_list")
                # func_n_file_cnt_txt=rf"{D_PKG_TXT}\{func_n}_{file_cnt}.txt"
                # write_list_to_file(texts=pnx_processed_list, pnx=func_n_file_cnt_txt, mode="w")
            func_n_file_cnt_txt = rf"{D_PKG_TXT}\{func_n}_{file_cnt}.txt"
            # pk_print(str_working=rf'''write_cnt="{write_cnt}"  {'%%%FOO%%%' if LTA else ''}''')
            write_str_to_f(msg=f"{pnx_with_walking}\n", f=func_n_file_cnt_txt, mode="a")
            write_cnt = write_cnt + 1
            if write_cnt == write_cnt_limit % 2 == 0:
                window_title = rf"{func_n}_{file_cnt}"
                # if not is_window_open(window_title_seg=window_title):
                #     open_pnx(pnx=func_n_file_cnt_txt)
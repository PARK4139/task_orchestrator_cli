



# import win32process



def remove_issue_code():
    pk_print(f'''issu_code is removed {'%%%FOO%%%' if LTA else ''}''')
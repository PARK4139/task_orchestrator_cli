



# import win32gui



def print_template_for_notion_issue_reporting(line_order, issues_list_csv):
    pk_print(working_str=rf'''노션 이슈발생 템플릿  {'%%%FOO%%%' if LTA else ''}''', print_color='white')
    collect_row_data = collect_row_data_from_csv(line_order=line_order, issues_list_csv=issues_list_csv)
    pk_print(string=f'''차량 : {collect_row_data["차량"]}''', print_color='white')
    pk_print(string=f'''지역 : {collect_row_data["지역"]}''', print_color='white')
    pk_print(string=f'''코스 : {collect_row_data["코스"]}''', print_color='white')
    pk_print(string=f'''운전자 : {collect_row_data['Crew']}''', print_color='white')
    # pk_print(string=f'''문제점 상세 : \n{collect_row_data["문제점 상세"].replace("\n\n","\n")}''', print_color='white')
    pk_print(string=f'''문제점 상세 : \n{collect_row_data["문제점 상세"].replace("\n", "")}''', print_color='white')
    pk_print(string=f'''''', print_color='white')
    pk_print(string=f'''SW 버전 : {collect_row_data["SW 버전"]}''', print_color='white')
    f위치 = collect_row_data["_f_ 위치"]
    if isinstance(f위치, float):
        f위치 = ""
    pk_print(string=f'''_f_명 : {f위치}''', print_color='white')
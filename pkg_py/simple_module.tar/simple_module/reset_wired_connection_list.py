



# import win32process
# import win32gui



def reset_wired_connection_list(wired_connection_no_range, **config_remote_os):
    for wired_connection_no in wired_connection_no_range:
        vpc_wired_connection = {'wired_connection_no': wired_connection_no, "address": rf"", "method": "auto",
                                "gateway": "", "dns": ""}
        set_wired_connection(vpc_wired_connection, **config_remote_os)
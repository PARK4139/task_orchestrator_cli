






def set_remote_os_as_nopasswd_v1(**config_remote_os):
    pw = config_remote_os['pw']
    cmd = "sudo grep -n 'nvidia ALL=(ALL:ALL) NOPASSWD:ALL' /etc/sudoers"
    std_out_list, std_err_list = cmd_to_remote_os_with_pw_via_paramiko(cmd=cmd, **config_remote_os)
    std_out = get_str_from_list(std_out_list)
    if "nvidia ALL=(ALL:ALL) NOPASSWD:ALL" in std_out:
        pk_print("The entry is already present.", 'green')
    else:
        cmd = f"echo '{pw}' | sudo -S bash -c \"echo 'nvidia ALL=(ALL:ALL) NOPASSWD:ALL' >> /etc/sudoers\""
        std_out_list, std_err_list = cmd_to_remote_os_with_pw_via_paramiko(cmd=cmd, **config_remote_os)
        cmd = f"sudo visudo -c"
        std_out_list, std_err_list = cmd_to_remote_os_with_pw_via_paramiko(cmd=cmd, **config_remote_os)
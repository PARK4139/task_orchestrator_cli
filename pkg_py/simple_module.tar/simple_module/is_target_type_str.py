



# import win32process


def is_target_type_str(target):
    func_n = inspect.currentframe().f_code.co_name
    if isinstance(target, str):
        return 1
    else:
        return 0
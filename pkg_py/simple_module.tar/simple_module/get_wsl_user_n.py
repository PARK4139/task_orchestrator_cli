





def get_wsl_user_n(wsl_distro_n):
    return get_user_n_wsl_via_whoami(wsl_disto_n=wsl_distro_n)
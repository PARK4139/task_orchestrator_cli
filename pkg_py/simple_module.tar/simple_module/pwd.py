



def pwd():
    print(())




# import win32gui



def get_pnx_new(d_working, pnx):
    # move_pnx 에  mode_count 로 통합
    """중복되지 않는 새로운 f명을 생성"""
    pnx_nx = get_nx(pnx)
    pnx_n, pnx_x = os.path.splitext(pnx_nx)
    counter = 1
    pnx_new = os.path.join(d_working, pnx_nx)
    while os.path.exists(pnx_new):
        pnx_new = os.path.join(d_working, f"{pnx_n}_{counter}{pnx_x}")
        counter += 1
    return get_pnx_unix_style(pnx=pnx_new)
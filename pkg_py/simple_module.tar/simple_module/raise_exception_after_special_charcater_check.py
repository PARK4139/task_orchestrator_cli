



# import win32gui
# import pywin32            
# import pywin32



def raise_exception_after_special_charcater_check(value, inspect_currentframe_f_code_co_name,
                                                  ignore_list: [str] = None):
    func_n = inspect.currentframe().f_code.co_name
    if is_containing_special_characters(value, ignore_list):
        word_english = inspect_currentframe_f_code_co_name
        word_english = word_english.replace('validate_', "")
        word_english = word_english.replace("_", " ")
        word_english = word_english.strip()
        word_korean = get_kor_from_eng(english_word=word_english)
        ment = f"유효한 {word_korean}이(가) 아닙니다. 특수문자가 없어야 합니다 {value}"
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail=ment)






def print_yellow(prompt, flush=True, line_feed_mode=1):
    print_prompt_via_colorama(prompt, ColormaColorMap.YELLOW, flush, line_feed_mode)
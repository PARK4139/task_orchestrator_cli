






def run_cmd_exe():
    cmd_to_os(cmd=rf"start cmd.exe /k", mode="a")
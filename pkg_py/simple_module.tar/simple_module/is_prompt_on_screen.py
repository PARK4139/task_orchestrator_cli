



# import win32gui
# import win32gui
# from project_database.test_project_database import MySqlUtil




def is_prompt_on_screen(prompt):
    # OCR을 통해 텍스트 추출
    screenshot = get_screenshot()
    extreact_texts = get_extreact_texts_from_image_via_easyocr(screenshot)
    text_extracted = " ".join([r[1] for r in extreact_texts])

    if is_prompt_in_text(prompt=prompt, text=text_extracted):
        return 1
    else:
        return 0
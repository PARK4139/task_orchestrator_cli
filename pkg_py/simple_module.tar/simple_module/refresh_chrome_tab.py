





    set_pk_context_state_milliseconds_for_speed_control_forcely



def refresh_chrome_tab(url_to_close):
    func_n = inspect.currentframe().f_code.co_name

    # minimize_all_windows()
    # window_title_seg = get_window_title(window_title_seg="Chrome")
    window_titles = get_window_title_list()

    timeout_seconds = 10
    start_time = time.time()
    for window_title_seg in window_titles:
        if "chrome".lower() in window_title_seg.lower():
            if timeout_seconds == 50:
                pk_print(working_str=rf'''window_title="{window_title_seg}"  {'%%%FOO%%%' if LTA else ''}''')
            while 1:
                elapsed_time = time.time() - start_time
                if elapsed_time > timeout_seconds:
                    break
                ensure_window_to_front(window_title_seg=window_title_seg)
                pk_sleep(milliseconds=15)
                pk_press("ctrl", "l")
                pk_sleep(milliseconds=15)
                url_dragged = get_text_dragged()
                if url_dragged == url_to_close:
                    pk_print(working_str=rf'''url_to_close="{url_to_close}"  {'%%%FOO%%%' if LTA else ''}''')
                    pk_print(working_str=rf'''url_dragged="{url_dragged}"  {'%%%FOO%%%' if LTA else ''}''')
                    pk_press("f5")
                    # restore_all_windows()
                    return
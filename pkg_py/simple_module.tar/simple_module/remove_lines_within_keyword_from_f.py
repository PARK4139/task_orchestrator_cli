



# import win32process



def remove_lines_within_keyword_from_f(f: str, keyword: str) -> None:
    from datetime import datetime

    # 변경 전 파일 백업
    # now = datetime.now().strftime("%y%m%d_%H%M")
    now = datetime.now().strftime("%y%m%d_%H")
    backup_path = f"{f}.{now}.bak"
    shutil.copy2(f, backup_path)
    if does_pnx_exist(pnx=backup_path):
        print(f"백업 파일 저장 완료: {backup_path}")

    # 특정 키워드가 포함된 줄 제거
    filtered_lines = []
    with open(f, 'r', encoding='utf-8') as f_obj:
        lines = f_obj.readlines()
        filtered_lines = [line for line in lines if keyword not in line]
    with open(f, 'w', encoding='utf-8') as f_obj:
        f_obj.writelines(filtered_lines)
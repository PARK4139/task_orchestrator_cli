







def get_pnx_os_style(pnx):
    if is_os_wsl_linux():
        pnx = get_pnx_wsl_unix_style(pnx=pnx)
        return pnx
    if is_os_windows():
        pnx = get_pnx_windows_style(pnx=pnx)
        return pnx
    else:
        pnx = get_pnx_unix_style(pnx=pnx)
        return pnx
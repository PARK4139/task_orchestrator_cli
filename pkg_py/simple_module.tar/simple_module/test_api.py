



# import win32process
# import win32gui
# import win32gui
# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely




def test_api():
    # def save_data_via_api_server():


    # SWAGGER ACCESS # FASTAPI # INCLUDE ROUTING TEST
    config = toml.load(F_CONFIG_TOML)
    pk_protocol_type = config["pk_uvicorn"]["protocol_type"]
    pk_host = config["pk_uvicorn"]["host"]
    pk_port = config["pk_uvicorn"]["port"]
    cmd_to_os(cmd=fr"explorer.exe {pk_protocol_type}://{pk_host}:{pk_port}/docs")
    cmd_to_os(cmd=fr"explorer.exe {pk_protocol_type}://{pk_host}:{pk_port}/redoc")
    cmd_to_os(cmd=fr"explorer.exe {pk_protocol_type}://{pk_host}:{pk_port}")

    # TODO : ROUTING TEST

    # POST REQUEST TEST
    url = "https://pk_system.store/api/db-maria/items"
    data = {
        "name": "John Doe",
        "email": "johndoe@example.com",
        "pw": "pw",
    }
    json_data = json.dumps(data)
    headers = {"Content-Type": "application/json"}
    response = requests.post(url, headers=headers, data=json_data)
    if response.status_code == 201:
        print("데이터가 성공적으로 저장되었습니다.")
    else:
        print("데이터 저장에 실패했습니다.")
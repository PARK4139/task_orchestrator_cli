





def kill_tabs_except_current_tab_via_selenium(driver):
    current_window = driver.current_window_handle
    for window in driver.window_handles:
        if window != current_window:
            driver.switch_to.window(window)
            # press("ctrl", "w"5)
            driver.close()  # 탭 닫기
            pk_sleep(seconds=0.1)
        #     pk_sleep(milliseconds=random.randint(a=22, b=2222))
        # pk_sleep(milliseconds=random.randint(a=22, b=2222))

    driver.switch_to.window(current_window)







def get_url_list_encoded_element(working_list):

    pk_print(f'''working_list={working_list}  {'%%%FOO%%%' if LTA else ''}''', print_color="blue")
    return [urllib.parse.quote(item) for item in working_list]
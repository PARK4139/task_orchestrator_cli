



# import win32gui
    set_pk_context_state_milliseconds_for_speed_control_forcely



def move_mouse(x_abs: float, y_abs: float, duration=1):
    # func_n = inspect.currentframe().f_code.co_name
    pyautogui.moveTo(x_abs, y_abs, duration)
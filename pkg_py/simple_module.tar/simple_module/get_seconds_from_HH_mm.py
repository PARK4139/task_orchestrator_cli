



# import win32process
# import win32gui
# import win32gui
# import pywin32
# import pywin32
# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely



def get_seconds_from_HH_mm(HH, mm):
    now = datetime.datetime.now()
    target_time = datetime.datetime(now.year, now.month, now.day, HH, mm)
    if now > target_time:
        target_time += datetime.timedelta(days=1)
    return (target_time - now).seconds
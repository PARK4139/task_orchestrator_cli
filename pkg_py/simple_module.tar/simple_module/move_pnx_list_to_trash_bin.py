





def move_pnx_list_to_trash_bin(pnx_list):
    for pnx in pnx_list:
        if does_pnx_exist(pnx):
            move_pnx_to_pk_recycle_bin(pnx=pnx)
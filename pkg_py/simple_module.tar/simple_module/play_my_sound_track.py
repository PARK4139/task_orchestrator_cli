



# import win32gui
# import win32gui
# import pywin32            
# import pywin32
# from project_database.test_project_database import MySqlUtil




def play_my_sound_track():

    func_n = inspect.currentframe().f_code.co_name

    # cmd_to_os(cmd=rf'taskkill /f /im "alsong.exe" ', debug_mode=True)

    cmd_to_os(cmd=rf'explorer "{F_PKG_SOUND_POTPLAYER64_DPL}" ')
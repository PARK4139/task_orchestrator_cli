



# import win32gui
# import pywin32



def pk_input_v1(working_str, limit_seconds, return_default, get_input_validated=None):
    from queue import Queue, Empty

    pk_print(f'''working_str={working_str} {'%%%FOO%%%' if LTA else ''}''')
    pk_print(f'''limit_seconds={limit_seconds} {'%%%FOO%%%' if LTA else ''}''')
    pk_print(f'''return_default={return_default} {'%%%FOO%%%' if LTA else ''}''')
    pk_print(f'''get_input_validated={get_input_validated} {'%%%FOO%%%' if LTA else ''}''')
    input_queue = Queue()

    def read_input():
        try:
            user_input = sys.stdin.readline()
            input_queue.put(user_input.strip())
        except Exception as e:
            input_queue.put(None)

    input_thread = threading.Thread(target=read_input, daemon=True)
    input_thread.start()

    start_time = time.time()
    remaining = limit_seconds

    try:
        while remaining > 0:
            user_input = ""
            try:
                user_input = input_queue.get(timeout=1)
                print()  # 줄 바꿈
                if get_input_validated and not get_input_validated(user_input):
                    pk_print("[RETRY] 유효하지 않은 입력입니다. 다시 시도해주세요.", print_color='red')
                    return pk_input(working_str, limit_seconds, return_default, get_input_validated)
                return user_input
            except Empty:
                remaining = limit_seconds - int(time.time() - start_time)
                print(f"\r⏳ remaining seconds : {remaining:2d} {working_str}{user_input}", end="", flush=True)
        print()  # 줄 바꿈 (시간 초과 시)
        pk_print(f"[TIMEOUT] 입력 시간 초과 → 기본값 반환: {return_default}", print_color='red')
        return return_default

    except KeyboardInterrupt:
        print()  # 줄 바꿈
        pk_print("[INTERRUPT] 사용자 입력 취소됨 → 기본값 반환", print_color='red')
        return return_default






def get_list_unioned(list_a, list_b):
    return list_a + list_b








def is_d(pnx):  # item_pnx
    if not is_f(pnx):
        return 1
    else:
        return 0
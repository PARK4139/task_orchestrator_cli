



# from project_database.test_project_database import MySqlUtil



def locate_dip_switchitch_on_board_to_left_down():
    # if no:
    #     left_down # 위치 재확인필요
    #     #         2개 스위치 제외(A/B selector, S/W 5) # 위치 재확인필요
    todo('%%%FOO%%%')
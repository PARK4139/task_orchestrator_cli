



# import pywin32
# from project_database.test_project_database import MySqlUtil




def write_str_to_vpc_flash_report_file(wroking_str, **config, ):
    # TODO
    vpc_type = config['vpc_type']
    flash_report_file_path = f"{vpc_type}_flash_report.txt"
    with open(flash_report_file_path, "a") as f:
        f.write(f"{wroking_str}\n")




def open_mouse_info():
    func_n = inspect.currentframe().f_code.co_name
    # pyautogui.mouseInfo()
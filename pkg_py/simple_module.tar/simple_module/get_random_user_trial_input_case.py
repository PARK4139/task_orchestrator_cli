





def get_random_user_trial_input_case():

    options = [
        get_random_korean_name(),
        get_random_korean_phone_number(),
        get_random_id(30),
        get_random_special_character(30),
        string.punctuation,
        get_random_special_character(30),
        # get_random_hex(),
        # get_random_bytes(),
        get_random_date(),
        "None",
        None,
        ""
    ]
    return random.choice(options)
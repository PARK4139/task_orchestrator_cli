



# from project_database.test_project_database import MySqlUtil
    set_pk_context_state_milliseconds_for_speed_control_forcely



def pk_oraganize_f_list_to_d_by_x(d_working, ext, d_dst):

    if not os.path.exists(d_dst):
        os.makedirs(d_dst)  # 대상 디렉토리가 없으면 생성

    # 파일 이름별로 정리
    f_nx_list_dict = {}
    for f_nx in os.listdir(d_working):
        f_n, f_x = os.path.splitext(f_nx)
        if f_x == ext:
            if f_n in f_nx_list_dict:
                f_nx_list_dict[f_n].append(f_nx)
            else:
                f_nx_list_dict[f_n] = [f_nx]
        else:
            if f_n not in f_nx_list_dict:
                f_nx_list_dict[f_n] = []

    for f_n, files in f_nx_list_dict.items():
        for f_nx in files:
            f_src = os.path.join(d_working, f_nx)
            d_dst = os.path.join(d_dst, f_nx)
            pk_print(f"Moving: {f_src} -> {d_dst}", print_color='green')
            move_pnx(pnx=f_src, d_dst=d_dst, sequential_mode=1)









def pk_input_validated(str_working, mode_verbose=1, mode_blank_validation=1, mode_nx_validation=1, mode_upper=1,
                       input_str=":"):
    # todo : pk_input_validated 를 pk_input 에 통합
    '''
    all mode default value is True
    '''

    while 1:
        if mode_upper:
            str_working = str_working.upper()
        pk_print(str_working, print_color='white', mode_verbose=mode_verbose)
        user_input = input(input_str).strip()
        if mode_blank_validation:
            if not user_input:
                pk_print("blank, name not allowed. Please try again.", print_color='red', mode_verbose=mode_verbose)
                continue
        if mode_nx_validation:
            if any(char in user_input for char in r'\/:*?"<>|'):
                pk_print("Char not allowed in f_n/d_n. Retry.", print_color='red')
                continue
        # todo : p일 조건 을
        # if p_validation_mode == True:
        #     if any(char not in user_input for char in r'\/:*?"<>|'):
        #         pk_print("Char not allowed in f_n/d_n. Retry.", print_color='red')
        #         continue
        return user_input






def print_cyan(prompt, flush=True, line_feed_mode=1):
    print_prompt_via_colorama(prompt, ColormaColorMap.CYAN, flush, line_feed_mode)
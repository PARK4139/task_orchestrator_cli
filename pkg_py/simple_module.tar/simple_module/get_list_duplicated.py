





# import win32process
# import pywin32
# import pywin32




def get_list_duplicated(working_list):
    func_n = inspect.currentframe().f_code.co_name
    items_duplicated = []
    seen = set()  # 이미 본 요소를 추적할 집합
    for item in working_list:
        if item in seen and item not in items_duplicated:
            items_duplicated.append(item)
        else:
            seen.add(item)
    return items_duplicated
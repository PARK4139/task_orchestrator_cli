







def shutdown_this_computer():
    cmd_to_os(rf'%windir%\System32\Shutdown.exe -s ')






def is_leaf_d(d):

    pk_print(f'''d={d}  {'%%%FOO%%%' if LTA else ''}''')
    try:
        contents = os.listdir(d)
        if len(contents) > 0:
            return 0
        for content in contents:
            pnx = os.path.join(d, content)
            if is_d(pnx):
                return 0
        return 1
    except:
        pk_print(f'''{traceback.format_exc()}  {'%%%FOO%%%' if LTA else ''}''', print_color='red')
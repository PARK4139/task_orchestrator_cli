







def print_light_white(prompt, flush=True, line_feed_mode=1):
    print_prompt_via_colorama(prompt, ColormaColorMap.LIGHTWHITE_EX, flush, line_feed_mode)
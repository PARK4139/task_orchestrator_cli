





def print_light_blue(prompt, flush=True, line_feed_mode=1):
    print_prompt_via_colorama(prompt, ColormaColorMap.LIGHTBLUE_EX, flush, line_feed_mode)
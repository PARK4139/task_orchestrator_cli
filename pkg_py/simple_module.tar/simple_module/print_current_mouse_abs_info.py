






def print_current_mouse_abs_info():

    func_n = inspect.currentframe().f_code.co_name
    x, y = get_current_mouse_abs_info()
    pk_print(f'''x="{x}"''')
    pk_print(f'''y="{y}"''')

    ipdb.set_trace()






# import pywin32
# import pywin32
# from project_database.test_project_database import MySqlUtil


def print_success(prompt, flush=True, line_feed_mode=1):
    print_prompt_via_colorama(prompt, ColormaColorMap.LIGHTGREEN_EX, flush, line_feed_mode)
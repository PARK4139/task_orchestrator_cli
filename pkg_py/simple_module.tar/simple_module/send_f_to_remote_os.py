



# import win32gui
# import pywin32
# import pywin32



def send_f_to_remote_os(f_local_src, f_remote_dst, **config_remote_os):

    ip = config_remote_os['ip']
    pw = config_remote_os['pw']
    port = config_remote_os['port']
    user_n = config_remote_os['user_n']

    f_local_src = get_pnx_os_style(f_local_src)
    if not os.path.exists(f_local_src):
        pk_print(f"{f_local_src} can not send, for not found", print_color='red')
        raise

    ssh = None
    sftp = None
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname=ip, port=port, username=user_n, password=pw)
        sftp = ssh.open_sftp()

        # send f_local
        pk_print(f"started to send f{(f_local_src)} to remote os({config_remote_os['ip']})")
        sftp.put(f_local_src, f_remote_dst)

        # f 전송 상태 확인
        f_local_size = os.path.getsize(f_local_src)
        f_remote_size = sftp.stat(f_remote_dst).st_size
        if f_local_size == f_remote_size:
            pk_print(f"send pnx ({f_remote_dst})", print_color="green")
            return 1  # 성공 시 True 반환
        else:
            pk_print(f"send pnx ({f_remote_dst})", print_color='red')
            raise
    except Exception as e:
        pk_print(f"send pnx : {e}", print_color='red')
        raise
    finally:
        # 리소스 정리
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()
        if LTA:
            pk_print(working_str="SSH connection closed.")
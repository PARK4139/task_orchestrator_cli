



# import win32gui



def validate_and_return(value: str):

    func_n = inspect.currentframe().f_code.co_name
    func_n = inspect.currentframe().f_code.co_name
    try:
        pk_print(rf'[벨리데이션 테스트 결과] [value={value}] [type(value)={type(value)}] [len(value)={len(value)}]')
    except:
        pass
    if value is None:
        pk_print(rf'[벨리데이션 테스트 결과] [value=None]')
        return 0
    if value == "":
        pk_print(rf'[벨리데이션 테스트 결과] [value=공백]')
        return 0
    # if 전화번호만 같아 보이는지
    # if 특수문자만 같아 보이는지
    return value




# import win32gui
    set_pk_context_state_milliseconds_for_speed_control_forcely





def print_state_debugger_for_lossless_cut(stamp, state_running, state_loading, state_loaded, state_playing):
    if LTA:
        pk_print(f'''state_running={state_running} {'%%%FOO%%%' if LTA else ''}''')
        pk_print(f'''state_loading={state_loading} {'%%%FOO%%%' if LTA else ''}''')
        pk_print(f'''state_loaded={state_loaded} {'%%%FOO%%%' if LTA else ''}''')
        pk_print(f'''state_playing={state_playing} {'%%%FOO%%%' if LTA else ''}''')
        pk_print(stamp)
        input('press enter')
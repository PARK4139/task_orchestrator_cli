



# from project_database.test_project_database import MySqlUtil




def get_pk_token(f_token, initial_str):

    f_master_key = rf"{D_PKG_TOML}/pk_token_key.toml"

    if not does_pnx_exist(pnx=f_master_key):
        ensure_pnx_removed(D_PK_TEMP)
        ensure_repo_cloned_via_git(repo_url='http://github.com/PARK4139/pkg_toml.git', d_dst=D_PK_TEMP)
        f_master_key_cloned = os.path.join(D_PK_TEMP, "pk_token_key.toml")
        if not os.path.exists(f_master_key_cloned):
            raise FileNotFoundError(f"Cloned key file not found at: {f_master_key_cloned}")
        move_pnx(pnx=f_master_key_cloned, d_dst=D_PKG_TOML)

    set_pk_plain_str(f_token=f_token, plain_str=initial_str, f_key=f_master_key)
    pk_plain_str = get_pk_plain_str(f_token=f_token, f_key=f_master_key)

    if LTA:
        pk_print(f'''pk_plain_str={pk_plain_str} {'%%%FOO%%%' if LTA else ''}''', print_color='blue')

    return pk_plain_str
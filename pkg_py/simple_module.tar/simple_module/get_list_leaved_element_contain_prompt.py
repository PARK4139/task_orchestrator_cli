



# import pywin32


def get_list_leaved_element_contain_prompt(working_list, prompt):
    return [f for f in working_list if prompt in f]
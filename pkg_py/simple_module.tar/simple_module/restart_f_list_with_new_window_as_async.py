





def restart_f_list_with_new_window_as_async(f_list):
    for f in f_list:
        asyncio.run(pk_kill_process_as_async(f=f))
    for f in f_list:
        asyncio.run(pk_run_process_as_async(f=f))




def pk_copy(working_str):
    # Set-Clipboard -Value "텍스트"  # 클립보드에 텍스트 저장
    clipboard.copy(working_str)
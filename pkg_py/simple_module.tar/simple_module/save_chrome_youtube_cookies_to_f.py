






def save_chrome_youtube_cookies_to_f():

    f_cookie = rf"{D_PKG_TXT}/chrome_youtube_cookies.txt"
    f_cookie = get_pnx_os_style(pnx=f_cookie)

    try:
        cj = browser_cookie3.chrome(domain_name=".youtube.com")  # Chrome에서 youtube.com 쿠키 가져오기
        with open(file=f_cookie, mode="w") as f:
            for cookie in cj:
                f.write(
                    f"{cookie.domain}\tTRUE\t{cookie.path}\tFALSE\t{cookie.expires}\t{cookie.name}\t{cookie.value}\n")
        pk_print(f"save cookies {f_cookie}", print_color="green")
    except:
        pk_print(f"save cookies {f_cookie}", print_color='red')
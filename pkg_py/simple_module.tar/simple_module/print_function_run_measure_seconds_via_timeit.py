



# import win32gui
# import win32gui
# import pywin32
# import pywin32



def print_function_run_measure_seconds_via_timeit(function, repeat):
    """
    특정 함수의 평균 exec  시간을 측정하여 로그로 출력합니다.
    """
    # todo : f에 결과즐 저장해서 통계를 내릴 수 있도록한다.
    from pk_system_layer_800_print_util import pk_print
    from functools import partial as functools_partial

    if isinstance(function, functools_partial):
        func_n = function.func.__name__
    else:
        func_n = function.__name__

    execution_time = timeit.timeit(function, number=repeat)
    pk_print(f"{func_n}() : {repeat}번 반복 평균 exec  시간: {execution_time:.6f} seconds", print_color='yellow')
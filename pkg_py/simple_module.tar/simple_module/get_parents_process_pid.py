



# import win32gui
# import pywin32
# import pywin32



def get_parents_process_pid():
    func_n = inspect.currentframe().f_code.co_name
    cmd = rf'powershell (Get-WmiObject Win32_Process -Filter ProcessId=$PID).ParentProcessId'
    lines = cmd_to_os_like_person_as_admin(cmd=cmd)
    lines = get_list_replaced_element_from_str_to_str(working_list=lines, from_str="\r", to_str="")
    return lines[0]
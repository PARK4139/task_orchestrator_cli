







def move_pnx_to_pk_recycle_bin(pnx):

    # import send2trash

    func_n = inspect.currentframe().f_code.co_name
    pnx = get_pnx_os_style(pnx=pnx)
    if does_pnx_exist(pnx):
        try:
            # send2trash.send2trash(pnx)
            # shutil.move(pnx, D_PK_RECYCLE_BIN)
            ensure_pnx_made(D_PK_RECYCLE_BIN, mode='d')
            move_pnx(pnx=pnx, d_dst=D_PK_RECYCLE_BIN)
        except:
            pk_print(f'''{traceback.format_exc()}  {'%%%FOO%%%' if LTA else ''}''', print_color='red')
    if does_pnx_exist(pnx):
        pk_print(f'''{func_n}  {'%%%FOO%%%' if LTA else ''}''', print_color='red')
    if not does_pnx_exist(pnx):
        pk_print(f'''{func_n}  {'%%%FOO%%%' if LTA else ''}''', print_color='green')
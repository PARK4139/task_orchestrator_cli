





def make_shellscript_version_new_via_hard_coded():

    func_n = inspect.currentframe().f_code.co_name

    make_shellscript_version_new_via_hard_coded_v_1_0_1()
    pass
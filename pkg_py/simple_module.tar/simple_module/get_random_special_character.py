



# import pywin32



def get_random_special_character(length_limit: int):

    result = ''
    for _ in range(length_limit):
        result += random.choice(string.printable)
    return
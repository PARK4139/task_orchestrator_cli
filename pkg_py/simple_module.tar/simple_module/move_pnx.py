



def move_pnx(pnx, d_dst, with_overwrite=0, sequential_mode=0, timestamp_mode=0):
    move_pnx_v2(pnx=pnx, d_dst=d_dst, with_overwrite=with_overwrite, sequential_mode=sequential_mode)




def pk_copy(str_working):
    clipboard.copy(str_working)
    return str_working
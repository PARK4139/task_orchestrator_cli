





def get_target_gigabite(target_path):
    return get_target_bite(target_path.strip()) / 1024 ** 3
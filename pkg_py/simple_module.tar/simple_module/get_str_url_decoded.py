



# import win32process
# import win32gui
    set_pk_context_state_milliseconds_for_speed_control_forcely



def get_str_url_decoded(str_working):
    from urllib.parse import quote
    return urllib.parse.unquote(str_working)